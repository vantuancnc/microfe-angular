declare module 'remote/AppComponent' {
    const AppComponent: any;
    export default AppComponent;
}