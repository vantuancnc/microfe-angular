import { CommonModule } from '@angular/common';
import { Component, ComponentRef, ViewChild, ViewContainerRef } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'host';
  @ViewChild('remoteContainer', { read: ViewContainerRef }) container!: ViewContainerRef;
  componentRef!: ComponentRef<any>;

  async ngAfterViewInit() {
    try {
      // Import component từ  project remote
      const remoteModule:any = await import('remote/AppComponent');
      const RemoteComponent = remoteModule.AppComponent;
      // Tạo instance của RemoteComponent và add vào ViewContainerRef
      this.componentRef = this.container.createComponent(RemoteComponent);
      
    } catch (error) {
      console.error("Failed to load Remote Component:", error);
    }
  }

}
